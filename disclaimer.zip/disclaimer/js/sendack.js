function sendAck(str) {
	
	var str = "foo"
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "getack.asp?q=" + str, true);
    xmlhttp.send();

}

 function GetUserLocale()
{
      window.external.GetUserLocale();
}