
    // Popup window code
	function MyPopUp(url) {
	 var newwindow;
   	 popupWindow = window.open (
        	url,'popUpWindow','height=500,width=500,left=0,top=200,titlebar=no,sresizable=no,scrollbars=yes,toolbar=no,menubar=no,location=no,directories=no,copyhistory=no,status=no')
	}
